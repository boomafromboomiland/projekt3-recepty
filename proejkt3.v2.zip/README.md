# README #

Czechitas Javascript 1 - Projekt zadaný na Lekci 10. Aplikace pro přehlednou kategorizaci receptů.

Zadání
---

- Uprav si recepty v `recepty.js` podle sebe. Přidej své oblíbené, doplň popisy a další informace.
- Zbytek zadání projektu je dostupný v souboru `app.js`.
- Během práce můžeš libovolně upravovat CSS, HTML i JS, přejmenovávat soubory, vytvářet nové a nepotřebné mazat. Je to čistě na tobě. :-)
- Svoji práci vhodně strukturuj a efektivně využívej Git.